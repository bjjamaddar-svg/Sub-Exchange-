import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, doc, getDoc, setDoc, updateDoc, deleteDoc, query, where, orderBy, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js";

// Firebase Console > Project settings > Your apps থেকে নিজের config বসান।
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const provider = new GoogleAuthProvider();

const $ = (id) => document.getElementById(id);
let currentUser = null;
let isAdmin = false;
let channelsCache = [];

$("year").textContent = new Date().getFullYear();

function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2800);
}
function safeChannelUrl(value) {
  try {
    const u = new URL(value);
    return u.protocol === "https:" && (u.hostname === "youtube.com" || u.hostname.endsWith(".youtube.com") || u.hostname === "youtu.be");
  } catch { return false; }
}
function escapeHtml(value="") {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}

$("login-btn").addEventListener("click", async () => {
  try { await signInWithPopup(auth, provider); }
  catch (e) { console.error(e); toast("Google Login সম্পন্ন হয়নি: " + e.message); }
});
$("logout-btn").addEventListener("click", async () => {
  await signOut(auth); toast("লগআউট হয়েছে");
});

onAuthStateChanged(auth, async user => {
  currentUser = user;
  isAdmin = false;
  $("login-btn").classList.toggle("hidden", !!user);
  $("logout-btn").classList.toggle("hidden", !user);
  $("user-label").textContent = user ? (user.displayName || user.email) : "";
  if (user) {
    await setDoc(doc(db, "users", user.uid), {
      displayName: user.displayName || "",
      email: user.email || "",
      photoURL: user.photoURL || "",
      lastSeen: serverTimestamp()
    }, { merge: true });
    const adminSnap = await getDoc(doc(db, "admins", user.uid));
    isAdmin = adminSnap.exists();
  }
  $("admin").classList.toggle("hidden", !isAdmin);
  await refreshData();
});

async function refreshData() {
  try {
    const q = query(collection(db, "channels"), where("status", "==", "approved"), orderBy("creatorPoints", "desc"));
    const snap = await getDocs(q);
    channelsCache = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    renderChannels(channelsCache);
    $("channel-count").textContent = channelsCache.length;
    $("creator-count").textContent = new Set(channelsCache.map(c => c.ownerUid).filter(Boolean)).size;
    if (currentUser) {
      const me = await getDoc(doc(db, "users", currentUser.uid));
      $("my-points").textContent = me.exists() ? (me.data().creatorPoints || 0) : 0;
    } else $("my-points").textContent = "—";
    if (isAdmin) await renderAdmin();
  } catch (e) {
    console.error(e);
    $("channel-list").innerHTML = '<p class="muted">ডেটা লোড করা যায়নি। Firebase config ও Firestore rules পরীক্ষা করুন।</p>';
  }
}

function renderChannels(items) {
  const list = $("channel-list");
  if (!items.length) { list.innerHTML = '<p class="muted">এখনো কোনো অনুমোদিত চ্যানেল নেই।</p>'; return; }
  list.innerHTML = items.map((c, i) => `
    <article class="channel-card">
      <div class="channel-top"><span class="rank">#${i+1} CREATOR</span><span class="points">${Number(c.creatorPoints || 0)} pts</span></div>
      <div><h3>${escapeHtml(c.name)}</h3><p>${escapeHtml(c.category || "Creator")}</p></div>
      <div class="channel-actions"><a class="btn btn-red" href="${escapeHtml(c.url)}" target="_blank" rel="noopener noreferrer">চ্যানেল দেখুন ↗</a></div>
    </article>`).join("");
}
$("search").addEventListener("input", e => {
  const term = e.target.value.toLowerCase();
  renderChannels(channelsCache.filter(c => (c.name || "").toLowerCase().includes(term) || (c.category || "").toLowerCase().includes(term)));
});

$("submit-form").addEventListener("submit", async e => {
  e.preventDefault();
  if (!currentUser) { toast("আবেদন করতে আগে Google দিয়ে লগইন করুন"); return; }
  const name = $("channel-name").value.trim();
  const url = $("channel-url").value.trim();
  const category = $("channel-category").value;
  if (!name || !safeChannelUrl(url)) { $("submit-message").textContent = "সঠিক নাম ও HTTPS YouTube URL দিন।"; return; }
  try {
    await addDoc(collection(db, "submissions"), {
      name, url, category, ownerUid: currentUser.uid,
      ownerName: currentUser.displayName || "",
      status: "pending", createdAt: serverTimestamp()
    });
    $("submit-form").reset();
    $("submit-message").textContent = "আবেদন জমা হয়েছে। Admin যাচাই করবেন।";
  } catch (err) { console.error(err); $("submit-message").textContent = "আবেদন জমা হয়নি। আবার চেষ্টা করুন।"; }
});

$("admin-form").addEventListener("submit", async e => {
  e.preventDefault();
  if (!isAdmin) return toast("Admin permission প্রয়োজন");
  const name = $("admin-channel-name").value.trim();
  const url = $("admin-channel-url").value.trim();
  const category = $("admin-channel-category").value.trim() || "Creator";
  const creatorPoints = Number($("admin-channel-points").value);
  if (!name || !safeChannelUrl(url) || !Number.isInteger(creatorPoints) || creatorPoints < 0) return toast("সঠিক তথ্য দিন");
  try {
    await addDoc(collection(db, "channels"), { name, url, category, creatorPoints, status:"approved", ownerUid:null, createdAt:serverTimestamp(), updatedAt:serverTimestamp() });
    $("admin-form").reset(); $("admin-channel-points").value = "0"; toast("চ্যানেল যুক্ত হয়েছে"); await refreshData();
  } catch (err) { console.error(err); toast("চ্যানেল যুক্ত করা যায়নি"); }
});

async function renderAdmin() {
  const pendingSnap = await getDocs(query(collection(db, "submissions"), where("status", "==", "pending")));
  $("pending-list").innerHTML = pendingSnap.empty ? '<p class="muted">কোনো Pending আবেদন নেই।</p>' : "";
  pendingSnap.forEach(s => {
    const x = s.data();
    const row = document.createElement("div"); row.className = "pending-item";
    row.innerHTML = `<div><strong>${escapeHtml(x.name)}</strong><p>${escapeHtml(x.category)} · ${escapeHtml(x.ownerName)}</p><a href="${escapeHtml(x.url)}" target="_blank" rel="noopener noreferrer">চ্যানেল দেখুন ↗</a></div>`;
    const actions = document.createElement("div");
    const approve = document.createElement("button"); approve.className = "btn btn-red"; approve.textContent = "Approve";
    approve.onclick = async () => {
      await addDoc(collection(db, "channels"), { name:x.name, url:x.url, category:x.category, creatorPoints:0, status:"approved", ownerUid:x.ownerUid, createdAt:serverTimestamp(), updatedAt:serverTimestamp() });
      await updateDoc(doc(db, "submissions", s.id), {status:"approved", reviewedAt:serverTimestamp()});
      toast("আবেদন অনুমোদিত"); await refreshData();
    };
    const reject = document.createElement("button"); reject.className = "btn btn-outline"; reject.textContent = "Reject";
    reject.onclick = async () => { await updateDoc(doc(db, "submissions", s.id), {status:"rejected", reviewedAt:serverTimestamp()}); toast("আবেদন বাতিল হয়েছে"); await refreshData(); };
    actions.append(approve,reject); row.append(actions); $("pending-list").append(row);
  });

  const allSnap = await getDocs(query(collection(db, "channels"), orderBy("createdAt", "desc")));
  $("admin-channel-list").innerHTML = "";
  allSnap.forEach(s => {
    const x=s.data(); const row=document.createElement("div"); row.className="pending-item";
    const info=document.createElement("div"); info.innerHTML=`<strong>${escapeHtml(x.name)}</strong><p>${Number(x.creatorPoints||0)} points · ${escapeHtml(x.status)}</p>`;
    const actions=document.createElement("div");
    const edit=document.createElement("button"); edit.className="btn btn-outline"; edit.textContent="Points";
    edit.onclick=async()=>{ const v=prompt("নতুন Creator Points লিখুন",String(x.creatorPoints||0)); if(v===null)return; const n=Number(v); if(!Number.isInteger(n)||n<0)return toast("সঠিক পয়েন্ট দিন"); await updateDoc(doc(db,"channels",s.id),{creatorPoints:n,updatedAt:serverTimestamp()}); await refreshData(); };
    const del=document.createElement("button"); del.className="btn btn-outline"; del.textContent="Delete";
    del.onclick=async()=>{if(confirm("চ্যানেলটি মুছে ফেলবেন?")){await deleteDoc(doc(db,"channels",s.id));await refreshData();}};
    actions.append(edit,del);row.append(info,actions);$("admin-channel-list").append(row);
  });
}
