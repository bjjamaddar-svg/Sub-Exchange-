# YouTube Go — Firebase Setup (বাংলা)

## কী আছে
- Google Authentication
- Firestore-এ চ্যানেল ও আবেদন সংরক্ষণ
- Admin-only dashboard (চ্যানেল যোগ/পয়েন্ট পরিবর্তন/ডিলিট)
- Visitor channel submission ও Admin approval
- Creator Points অনুযায়ী ranking
- Responsive dark/red design

## ১. Firebase Project তৈরি
1. https://console.firebase.google.com খুলে Add project চাপুন।
2. Project name দিন `youtube-go` (অথবা আপনার পছন্দমতো)।
3. Authentication > Sign-in method > Google Enable করুন।
4. Authentication > Settings > Authorized domains-এ আপনার Hosting domain যোগ আছে কি না দেখুন।
5. Firestore Database তৈরি করুন (Production mode)।
6. Project settings > General > Your apps > Web app তৈরি করে Firebase config কপি করুন।

## ২. Firebase config বসানো
`public/app.js` ফাইলে `firebaseConfig`-এর `YOUR_...` মানগুলো নিজের Firebase Web App config দিয়ে বদলান। Firebase config-এ API key থাকে; এটি public client config, কিন্তু নিরাপত্তা Firestore Rules ও Firebase App Check দিয়ে নিশ্চিত করতে হবে।

## ৩. প্রথম Admin তৈরি
1. প্রথমে সাইটে Google দিয়ে একবার লগইন করুন।
2. Firebase Console > Firestore Database > Data খুলুন।
3. `admins` নামে collection তৈরি করুন।
4. Document ID হিসেবে আপনার Firebase Authentication-এর User UID বসান।
5. ওই document-এ `enabled` (boolean) = `true` যোগ করুন।
6. Admin dashboard দেখাতে সাইটে আবার লগইন করুন।

**সতর্কতা:** Admin UID কাউকে দেবেন না। `admins` collection-এ নতুন UID যোগ করলেই তাকে Admin ক্ষমতা দেওয়া হয়।

## ৪. Firestore Rules প্রকাশ
Firebase Console > Firestore Database > Rules-এ `firestore.rules`-এর সম্পূর্ণ বিষয়বস্তু পেস্ট করে Publish করুন।

## ৫. Hosting deploy
কম্পিউটারে Node.js ইনস্টল করে Terminal/Command Prompt-এ:
```bash
npm install -g firebase-tools
firebase login
firebase use --add
firebase deploy
```
`firebase use --add`-এ আপনার Firebase project বেছে নিন। `.firebaserc.example` কপি করে `.firebaserc` নাম দিতে পারেন এবং project ID বসাতে পারেন।

## ৬. পরীক্ষা
- Google login/logout
- সাধারণ user দিয়ে channel submission
- Admin account দিয়ে pending application approve/reject
- Admin দিয়ে channel add/delete ও Creator Points update
- Incognito window-তে public approved channel দেখা

## নিরাপত্তা ও নীতিমালা
- কোনো visitor-এর Gmail password কখনো সংগ্রহ করবেন না। শুধু Google OAuth popup ব্যবহার করুন।
- Subscribe/like/view-এর বিনিময়ে points বা পুরস্কার দেবেন না। YouTube-এর fake engagement policy এ ধরনের incentivized engagement নিষিদ্ধ করতে পারে।
- Points কেবল profile completion, তথ্য যাচাই বা প্রকৃত কমিউনিটি অবদানের মতো অনুমোদিত কাজে দিন।
- Production চালুর আগে Firebase App Check, billing alerts, abuse protection, privacy policy ও terms যোগ করুন।
- এই starter-এ points Admin হাতে পরিবর্তন করেন। স্বয়ংক্রিয় points-awarding workflow ইচ্ছাকৃতভাবে রাখা হয়নি।
